//+-----------------------------------------------------------------------------
//| Included files
//+-----------------------------------------------------------------------------
#include "War3ModelImporter.h"


//+-----------------------------------------------------------------------------
//| Imports a model
//|
//| Instructions:
//|   The imported model will be given as a chunk of raw data of size DataSize
//|   pointed by the Data pointer. This is simply a direct copy of the file.
//|   Use the ModelBuilder interface to construct a model from this data.
//|   If the model loading succeeds (no errors occured) the function should
//|   return TRUE. If an error occured it should return FALSE. You can set
//|   an error message if the loading failed by calling the SetErrorMessage
//|   method in the ModelBuilder interface. If not a default error message
//|   will be displayed.
//|
//|   All created objects are referenced by ID's (like GeosetId). This is
//|   their zero-based index in the order they're created. The first object
//|   to be created has index 0, the next 1 and so on. All different components
//|   have their own storage so if you create a geoset it gets index 0. If you
//|   then create a bone it also gets index 0 (not 1) since it uses another
//|   storage.
//|
//|   Some objects have animated fields. When you first create an object with
//|   an animated field the field will default to static. To make it animated
//|   create an interpolator, add the neccessary nodes (Add***) then call
//|   the appropriate SetAnimated*** method. This will set that field to the
//|   last created interpolator. Note that the nodes have to be added in
//|   increasing order (according to the time). If not the results are
//|   undefined. For best results make sure you know which type each field
//|   has, like Visibility is SCALAR, TextureId is SCALAR_INT, Translation is
//|   VECTOR_3 etc... Otherwise you may end up with odd results.
//|
//|   Names are CHAR-pointers, so if you want to give a new name simply
//|   repoint the pointer. Do NOT use std::strcpy!!!
//|
//|   No exporter support at this point. Maybe in future versions.
//|
//+-----------------------------------------------------------------------------
extern "C" DLL BOOL DllImport(WAR3_MODEL_BUILDER* ModelBuilder, CONST CHAR* FileName, CONST CHAR* Data, INT DataSize)
{
	//*********************************
	//* Implement me!
	//*********************************

	return TRUE;
}


//+-----------------------------------------------------------------------------
//| Main function that is run when the DLL is loaded and unloaded
//+-----------------------------------------------------------------------------
BOOL WINAPI DllMain(HINSTANCE Dll, DWORD Reason, LPVOID Reserved)
{
	return TRUE;
}
