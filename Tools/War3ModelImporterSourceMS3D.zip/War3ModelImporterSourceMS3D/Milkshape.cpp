//+-----------------------------------------------------------------------------
//| Included files
//+-----------------------------------------------------------------------------
#include "Milkshape.h"


//+-----------------------------------------------------------------------------
//| Global objects
//+-----------------------------------------------------------------------------
MILKSHAPE Milkshape;


//+-----------------------------------------------------------------------------
//| Constructor
//+-----------------------------------------------------------------------------
MILKSHAPE::MILKSHAPE()
{
	FilePointer.Void = NULL;
	CurrentFileName = "";

	CorrectCoordinateSystem = FALSE;
}


//+-----------------------------------------------------------------------------
//| Destructor
//+-----------------------------------------------------------------------------
MILKSHAPE::~MILKSHAPE()
{
	Clear();
}


//+-----------------------------------------------------------------------------
//| Clears the current model data
//+-----------------------------------------------------------------------------
VOID MILKSHAPE::Clear()
{
	ZeroMemory(&Header, sizeof(MILKSHAPE_HEADER));
	ZeroMemory(&AnimationHeader, sizeof(MILKSHAPE_ANIMATION_HEADER));

	VertexList.clear();
	FaceList.clear();
	GroupList.clear();
	MaterialList.clear();
	JointList.clear();

	GroupCommentList.clear();
	MaterialCommentList.clear();
	JointCommentList.clear();
	ModelCommentList.clear();

	FilePointer.Void = NULL;
	CurrentFileName = "";
}


//+-----------------------------------------------------------------------------
//| Imports a milkshape model
//+-----------------------------------------------------------------------------
BOOL MILKSHAPE::Import(WAR3_MODEL_BUILDER* ModelBuilder, CONST std::string& FileName, CONST CHAR* Data, INT DataSize)
{
	Clear();

	FilePointer.Size = DataSize;
	FilePointer.First = Data;
	FilePointer.Char = FilePointer.First;
	CurrentFileName = FileName;

	CorrectCoordinateSystem = TRUE;

	if(!ReadMilkshapeData(ModelBuilder)) return FALSE;
	if(!BuildModel(ModelBuilder)) return FALSE;

	return TRUE;
}


//+-----------------------------------------------------------------------------
//| Reads the milkshape data from the file
//+-----------------------------------------------------------------------------
BOOL MILKSHAPE::ReadMilkshapeData(WAR3_MODEL_BUILDER* ModelBuilder)
{
	INT i;
	INT j;
	INT Size;
	INT Index;
	INT NrOfVertices;
	INT NrOfFaces;
	INT NrOfGroups;
	INT NrOfMaterials;
	INT NrOfJoints;
	INT NrOfGroupComments;
	INT NrOfMaterialComments;
	INT NrOfJointComments;
	INT NrOfModelComments;

	for(i = 0; i < 10; i++) Header.MagicNumber[i] = *FilePointer.Char++;
	Header.Version = static_cast<INT>(*FilePointer.DWord++);

	if(std::memcmp(Header.MagicNumber, "MS3D000000", 10) != 0)
	{
		ModelBuilder->SetErrorMessage("The file is not a Milkshape model!");
		return FALSE;
	}

	NrOfVertices = static_cast<INT>(*FilePointer.Word++);
	VertexList.resize(NrOfVertices);

	for(i = 0; i < NrOfVertices; i++)
	{
		VertexList[i].Flags = static_cast<INT>(*FilePointer.Byte++);
		VertexList[i].Position.x = *FilePointer.Float++;
		VertexList[i].Position.y = *FilePointer.Float++;
		VertexList[i].Position.z = *FilePointer.Float++;
		VertexList[i].BoneIndex = static_cast<INT>(*FilePointer.Char++);
		VertexList[i].ReferenceCount = static_cast<INT>(*FilePointer.Byte++);

		CorrectPosition(VertexList[i].Position);
	}

	NrOfFaces = static_cast<INT>(*FilePointer.Word++);
	FaceList.resize(NrOfFaces);

	for(i = 0; i < NrOfFaces; i++)
	{
		FaceList[i].Flags = static_cast<INT>(*FilePointer.Word++);
		FaceList[i].Index1 = static_cast<INT>(*FilePointer.Word++);
		FaceList[i].Index2 = static_cast<INT>(*FilePointer.Word++);
		FaceList[i].Index3 = static_cast<INT>(*FilePointer.Word++);
		FaceList[i].Normal1.x = *FilePointer.Float++;
		FaceList[i].Normal1.y = *FilePointer.Float++;
		FaceList[i].Normal1.z = *FilePointer.Float++;
		FaceList[i].Normal2.x = *FilePointer.Float++;
		FaceList[i].Normal2.y = *FilePointer.Float++;
		FaceList[i].Normal2.z = *FilePointer.Float++;
		FaceList[i].Normal3.x = *FilePointer.Float++;
		FaceList[i].Normal3.y = *FilePointer.Float++;
		FaceList[i].Normal3.z = *FilePointer.Float++;
		FaceList[i].TexturePosition1.x = *FilePointer.Float++;
		FaceList[i].TexturePosition2.x = *FilePointer.Float++;
		FaceList[i].TexturePosition3.x = *FilePointer.Float++;
		FaceList[i].TexturePosition1.y = *FilePointer.Float++;
		FaceList[i].TexturePosition2.y = *FilePointer.Float++;
		FaceList[i].TexturePosition3.y = *FilePointer.Float++;
		FaceList[i].SmoothingGroup = static_cast<INT>(*FilePointer.Byte++);
		FaceList[i].GroupIndex = static_cast<INT>(*FilePointer.Byte++);

		CorrectPosition(FaceList[i].Normal1);
		CorrectPosition(FaceList[i].Normal2);
		CorrectPosition(FaceList[i].Normal3);
	}

	NrOfGroups = static_cast<INT>(*FilePointer.Word++);
	GroupList.resize(NrOfGroups);

	for(i = 0; i < NrOfGroups; i++)
	{
		GroupList[i].Flags = static_cast<INT>(*FilePointer.Byte++);
		GroupList[i].Name = ReadString(32);
		GroupList[i].NrOfFaces = static_cast<INT>(*FilePointer.Word++);

		GroupList[i].FaceList.resize(GroupList[i].NrOfFaces);
		for(j = 0; j < GroupList[i].NrOfFaces; j++)
		{
			GroupList[i].FaceList[j] = static_cast<INT>(*FilePointer.Word++);
		}

		GroupList[i].MaterialIndex = static_cast<INT>(*FilePointer.Char++);
	}

	NrOfMaterials = static_cast<INT>(*FilePointer.Word++);
	MaterialList.resize(NrOfMaterials);

	for(i = 0; i < NrOfMaterials; i++)
	{
		MaterialList[i].Name = ReadString(32);
		MaterialList[i].AmbientColor.r = *FilePointer.Float++;
		MaterialList[i].AmbientColor.g = *FilePointer.Float++;
		MaterialList[i].AmbientColor.b = *FilePointer.Float++;
		MaterialList[i].AmbientColor.a = *FilePointer.Float++;
		MaterialList[i].DiffuseColor.r = *FilePointer.Float++;
		MaterialList[i].DiffuseColor.g = *FilePointer.Float++;
		MaterialList[i].DiffuseColor.b = *FilePointer.Float++;
		MaterialList[i].DiffuseColor.a = *FilePointer.Float++;
		MaterialList[i].SpecularColor.r = *FilePointer.Float++;
		MaterialList[i].SpecularColor.g = *FilePointer.Float++;
		MaterialList[i].SpecularColor.b = *FilePointer.Float++;
		MaterialList[i].SpecularColor.a = *FilePointer.Float++;
		MaterialList[i].EmissiveColor.r = *FilePointer.Float++;
		MaterialList[i].EmissiveColor.g = *FilePointer.Float++;
		MaterialList[i].EmissiveColor.b = *FilePointer.Float++;
		MaterialList[i].EmissiveColor.a = *FilePointer.Float++;
		MaterialList[i].Shininess = *FilePointer.Float++;
		MaterialList[i].Transparency = *FilePointer.Float++;
		MaterialList[i].Mode = static_cast<INT>(*FilePointer.Char++);
		MaterialList[i].TextureFileName = ReadString(128);
		MaterialList[i].AlphaFileName = ReadString(128);
	}

	AnimationHeader.Fps = *FilePointer.Float++;
	AnimationHeader.CurrentTime = *FilePointer.Float++;
	AnimationHeader.NrOfFrames = static_cast<INT>(*FilePointer.DWord++);

	NrOfJoints = static_cast<INT>(*FilePointer.Word++);
	JointList.resize(NrOfJoints);

	for(i = 0; i < NrOfJoints; i++)
	{
		JointList[i].Flags = static_cast<INT>(*FilePointer.Byte++);

		JointList[i].Name = ReadString(32);
		JointList[i].ParentName = ReadString(32);
		JointList[i].Rotation.x = *FilePointer.Float++;
		JointList[i].Rotation.y = *FilePointer.Float++;
		JointList[i].Rotation.z = *FilePointer.Float++;
		JointList[i].Translation.x = *FilePointer.Float++;
		JointList[i].Translation.y = *FilePointer.Float++;
		JointList[i].Translation.z = *FilePointer.Float++;
		JointList[i].NrOfRotationTracks = static_cast<INT>(*FilePointer.Word++);
		JointList[i].NrOfTranslationTracks = static_cast<INT>(*FilePointer.Word++);

		JointList[i].RotationTrackList.resize(JointList[i].NrOfRotationTracks);
		for(j = 0; j < JointList[i].NrOfRotationTracks; j++)
		{
			JointList[i].RotationTrackList[j].Time = *FilePointer.Float++;
			JointList[i].RotationTrackList[j].Rotation.x = *FilePointer.Float++;
			JointList[i].RotationTrackList[j].Rotation.y = *FilePointer.Float++;
			JointList[i].RotationTrackList[j].Rotation.z = *FilePointer.Float++;

			CorrectPosition(JointList[i].RotationTrackList[j].Rotation);
		}

		JointList[i].TranslationTrackList.resize(JointList[i].NrOfTranslationTracks);
		for(j = 0; j < JointList[i].NrOfTranslationTracks; j++)
		{
			JointList[i].TranslationTrackList[j].Time = *FilePointer.Float++;
			JointList[i].TranslationTrackList[j].Translation.x = *FilePointer.Float++;
			JointList[i].TranslationTrackList[j].Translation.y = *FilePointer.Float++;
			JointList[i].TranslationTrackList[j].Translation.z = *FilePointer.Float++;

			CorrectPosition(JointList[i].TranslationTrackList[j].Translation);
		}

		CorrectPosition(JointList[i].Rotation);
		CorrectPosition(JointList[i].Translation);
	}

	if((FilePointer.Char - FilePointer.First) >= FilePointer.Size) return TRUE;

	Header.SubVersion = static_cast<INT>(*FilePointer.DWord++);

	NrOfGroupComments = static_cast<INT>(*FilePointer.DWord++);
	GroupCommentList.resize(NrOfGroupComments);

	for(i = 0; i < NrOfGroupComments; i++)
	{
		Index = static_cast<INT>(*FilePointer.DWord++);
		Size = static_cast<INT>(*FilePointer.DWord++);
		GroupCommentList[i] = ReadString(Size);
	}

	NrOfMaterialComments = static_cast<INT>(*FilePointer.DWord++);
	MaterialCommentList.resize(NrOfMaterialComments);

	for(i = 0; i < NrOfMaterialComments; i++)
	{
		Index = static_cast<INT>(*FilePointer.DWord++);
		Size = static_cast<INT>(*FilePointer.DWord++);
		MaterialCommentList[i] = ReadString(Size);
	}

	NrOfJointComments = static_cast<INT>(*FilePointer.DWord++);
	JointCommentList.resize(NrOfJointComments);

	for(i = 0; i < NrOfJointComments; i++)
	{
		Index = static_cast<INT>(*FilePointer.DWord++);
		Size = static_cast<INT>(*FilePointer.DWord++);
		JointCommentList[i] = ReadString(Size);
	}

	NrOfModelComments = static_cast<INT>(*FilePointer.DWord++);
	ModelCommentList.resize(NrOfModelComments);

	for(i = 0; i < NrOfModelComments; i++)
	{
		Index = static_cast<INT>(*FilePointer.DWord++);
		Size = static_cast<INT>(*FilePointer.DWord++);
		ModelCommentList[i] = ReadString(Size);
	}

	return TRUE;
}


//+-----------------------------------------------------------------------------
//| Reads a fixed-length string
//+-----------------------------------------------------------------------------
std::string MILKSHAPE::ReadString(INT Size)
{
	INT i;
	std::vector<CHAR> Buffer;

	Buffer.resize(Size + 1);
	Buffer[Size] = '\0';

	for(i = 0; i < Size; i++) Buffer[i] = *FilePointer.Char++;

	return &Buffer[0];
}


//+-----------------------------------------------------------------------------
//| Builds the model from the milkshape data
//+-----------------------------------------------------------------------------
BOOL MILKSHAPE::BuildModel(WAR3_MODEL_BUILDER* ModelBuilder)
{
	INT i;
	INT j;
	INT Time;
	INT Index;
	INT LastTime;
	WAR3_MODEL_SEQUENCE Sequence;
	std::vector<std::string> TextureList;
	std::map<std::string, INT> TextureMap;
	std::map<std::string, INT>::iterator TextureMapIterator;
	std::vector<INT> BoneParentList;
	std::vector<BOOL> BoneIsParentList;
	std::map<std::string, INT> BoneMap;
	std::map<std::string, INT>::iterator BoneMapIterator;
	std::list<INT> BoneList;

	for(i = 0; i < static_cast<INT>(MaterialList.size()); i++)
	{
		WAR3_MODEL_TEXTURE Texture;

		TextureMapIterator = TextureMap.find(MaterialList[i].TextureFileName);
		if(TextureMapIterator == TextureMap.end())
		{
			Index = static_cast<INT>(TextureList.size());
			TextureList.push_back(MaterialList[i].TextureFileName);
			TextureMap.insert(std::make_pair(MaterialList[i].TextureFileName, Index));

			Texture.FileName = MaterialList[i].TextureFileName.c_str();
			if(!ModelBuilder->CreateTexture(Texture)) return FALSE;
		}
		else
		{
			Index = TextureMapIterator->second;
		}
	}

	for(i = 0; i < static_cast<INT>(MaterialList.size()); i++)
	{
		WAR3_MODEL_MATERIAL Material;
		WAR3_MODEL_MATERIAL_LAYER MaterialLayer;

		TextureMapIterator = TextureMap.find(MaterialList[i].TextureFileName);
		MaterialLayer.TextureId = (TextureMapIterator == TextureMap.end()) ? WAR3_INVALID_ID : TextureMapIterator->second;

		if(!ModelBuilder->CreateMaterial(Material)) return FALSE;
		if(!ModelBuilder->CreateMaterialLayer(i, MaterialLayer)) return FALSE;
	}

	for(i = 0; i < static_cast<INT>(JointList.size()); i++)
	{
		BoneParentList.push_back(WAR3_INVALID_ID);
		BoneIsParentList.push_back(FALSE);
		BoneMap.insert(std::make_pair(JointList[i].Name, i));
	}

	for(i = 0; i < static_cast<INT>(JointList.size()); i++)
	{
		BoneMapIterator = BoneMap.find(JointList[i].ParentName);
		if(BoneMapIterator != BoneMap.end())
		{
			BoneParentList[i] = BoneMapIterator->second;
			BoneIsParentList[BoneMapIterator->second] = TRUE;
		}
	}

	for(i = 0; i < static_cast<INT>(JointList.size()); i++)
	{
		if(BoneParentList[i] == WAR3_INVALID_ID) BoneList.push_back(i);
	}

	while(BoneList.size() > 0)
	{
		Index = BoneList.front();
		BoneList.pop_front();

		for(i = 0; i < static_cast<INT>(JointList.size()); i++)
		{
			if(BoneParentList[i] == Index) BoneList.push_back(i);
		}

		if(BoneParentList[Index] != WAR3_INVALID_ID)
		{
			JointList[Index].Translation += JointList[BoneParentList[Index]].Translation;
		}
	}

	LastTime = 0;

	for(i = 0; i < static_cast<INT>(JointList.size()); i++)
	{
		D3DXMATRIX Matrix;
		D3DXVECTOR4 TempVector;
		WAR3_MODEL_BONE Bone;
		WAR3_MODEL_PIVOT_POINT PivotPoint;

		D3DXMatrixRotationYawPitchRoll(&Matrix, JointList[i].Rotation.y, JointList[i].Rotation.x, JointList[i].Rotation.z);
		D3DXVec3Transform(&TempVector, &JointList[i].Translation, &Matrix);

		PivotPoint.Position.X = TempVector.x;
		PivotPoint.Position.Y = TempVector.y;
		PivotPoint.Position.Z = TempVector.z;

		if(!ModelBuilder->CreatePivotPoint(PivotPoint)) return FALSE;

		Bone.Node.Name = JointList[i].Name.c_str();
		Bone.Node.ObjectId = i;
		Bone.Node.ParentId = BoneParentList[i];

		if(!ModelBuilder->CreateBone(Bone)) return FALSE;

		if(!ModelBuilder->CreateInterpolator()) return FALSE;
		ModelBuilder->SetInterpolatorType(WAR3_INTERPOLATOR_TYPE_VECTOR4);
		ModelBuilder->SetInterpolatorInterpolationType(WAR3_INTERPOLATION_TYPE_LINEAR);

		for(j = 0; j < static_cast<INT>(JointList[i].RotationTrackList.size()); j++)
		{
			D3DXQUATERNION Quaternion;
			WAR3_MODEL_VECTOR_4 Vector;
			D3DXVECTOR3 TempVector;

			TempVector.x = JointList[i].RotationTrackList[j].Rotation.x;
			TempVector.y = JointList[i].RotationTrackList[j].Rotation.y;
			TempVector.z = JointList[i].RotationTrackList[j].Rotation.z;

			D3DXQuaternionRotationYawPitchRoll(&Quaternion, TempVector.y, TempVector.x, TempVector.z);

			Vector.X = Quaternion.x;
			Vector.Y = Quaternion.y;
			Vector.Z = Quaternion.z;
			Vector.W = Quaternion.w;

			Time = static_cast<INT>(JointList[i].RotationTrackList[j].Time * 1000.0f);
			ModelBuilder->AddVector4(Time, Vector, Vector, Vector);

			if(Time > LastTime) LastTime = Time;
		}

		ModelBuilder->SetAnimatedBoneRotation(i);

		if(!ModelBuilder->CreateInterpolator()) return FALSE;
		ModelBuilder->SetInterpolatorType(WAR3_INTERPOLATOR_TYPE_VECTOR3);
		ModelBuilder->SetInterpolatorInterpolationType(WAR3_INTERPOLATION_TYPE_LINEAR);

		for(j = 0; j < static_cast<INT>(JointList[i].TranslationTrackList.size()); j++)
		{
			WAR3_MODEL_VECTOR_3 Vector;

			Vector.X = JointList[i].TranslationTrackList[j].Translation.x;
			Vector.Y = JointList[i].TranslationTrackList[j].Translation.y;
			Vector.Z = JointList[i].TranslationTrackList[j].Translation.z;

			Time = static_cast<INT>(JointList[i].TranslationTrackList[j].Time * 1000.0f);
			ModelBuilder->AddVector3(Time, Vector, Vector, Vector);

			if(Time > LastTime) LastTime = Time;
		}

		ModelBuilder->SetAnimatedBoneTranslation(i);
	}

	for(i = 0; i < static_cast<INT>(GroupList.size()); i++)
	{
		WAR3_MODEL_GEOSET Geoset;

		Geoset.MaterialId = GroupList[i].MaterialIndex;

		if(!ModelBuilder->CreateGeoset(Geoset)) return FALSE;

		for(j = 0; j < static_cast<INT>(JointList.size()); j++)
		{
			if(!ModelBuilder->CreateGeosetGroup(i)) return FALSE;
			if(!ModelBuilder->CreateGeosetGroupBone(i, j, j)) return FALSE;
		}

		for(j = 0; j < GroupList[i].NrOfFaces; j++)
		{
			WAR3_MODEL_FACE Face;
			WAR3_MODEL_VERTEX Vertex;

			Index = GroupList[i].FaceList[j];

			Vertex.Position.X = VertexList[FaceList[Index].Index1].Position.x;
			Vertex.Position.Y = VertexList[FaceList[Index].Index1].Position.y;
			Vertex.Position.Z = VertexList[FaceList[Index].Index1].Position.z;
			Vertex.Normal.X = FaceList[Index].Normal1.x;
			Vertex.Normal.Y = FaceList[Index].Normal1.y;
			Vertex.Normal.Z = FaceList[Index].Normal1.z;
			Vertex.TexturePosition.X = FaceList[Index].TexturePosition1.x;
			Vertex.TexturePosition.Y = FaceList[Index].TexturePosition1.y;
			Vertex.Group = VertexList[FaceList[Index].Index1].BoneIndex;

			if(!ModelBuilder->CreateGeosetVertex(i, Vertex)) return FALSE;

			Vertex.Position.X = VertexList[FaceList[Index].Index2].Position.x;
			Vertex.Position.Y = VertexList[FaceList[Index].Index2].Position.y;
			Vertex.Position.Z = VertexList[FaceList[Index].Index2].Position.z;
			Vertex.Normal.X = FaceList[Index].Normal2.x;
			Vertex.Normal.Y = FaceList[Index].Normal2.y;
			Vertex.Normal.Z = FaceList[Index].Normal2.z;
			Vertex.TexturePosition.X = FaceList[Index].TexturePosition2.x;
			Vertex.TexturePosition.Y = FaceList[Index].TexturePosition2.y;
			Vertex.Group = VertexList[FaceList[Index].Index2].BoneIndex;

			if(!ModelBuilder->CreateGeosetVertex(i, Vertex)) return FALSE;

			Vertex.Position.X = VertexList[FaceList[Index].Index3].Position.x;
			Vertex.Position.Y = VertexList[FaceList[Index].Index3].Position.y;
			Vertex.Position.Z = VertexList[FaceList[Index].Index3].Position.z;
			Vertex.Normal.X = FaceList[Index].Normal3.x;
			Vertex.Normal.Y = FaceList[Index].Normal3.y;
			Vertex.Normal.Z = FaceList[Index].Normal3.z;
			Vertex.TexturePosition.X = FaceList[Index].TexturePosition3.x;
			Vertex.TexturePosition.Y = FaceList[Index].TexturePosition3.y;
			Vertex.Group = VertexList[FaceList[Index].Index3].BoneIndex;

			if(!ModelBuilder->CreateGeosetVertex(i, Vertex)) return FALSE;

			Face.Index1 = (j * 3) + 0;
			Face.Index2 = (j * 3) + 1;
			Face.Index3 = (j * 3) + 2;

			if(!ModelBuilder->CreateGeosetFace(i, Face)) return FALSE;
		}
	}

	Sequence.Name = "Unnamed";
	Sequence.IntervalStart = 0;
	Sequence.IntervalEnd = LastTime;

	if(!ModelBuilder->CreateSequence(Sequence)) return FALSE;

	return TRUE;
}


//+-----------------------------------------------------------------------------
//| Corrects the coordinate system for a position
//+-----------------------------------------------------------------------------
VOID MILKSHAPE::CorrectPosition(D3DXVECTOR3& Position)
{
	D3DXMATRIX Matrix;
	D3DXMATRIX MatrixRotationX;
	D3DXMATRIX MatrixRotationY;
	D3DXVECTOR4 TempVector;

	if(!CorrectCoordinateSystem) return;

	D3DXMatrixRotationX(&MatrixRotationX, (D3DX_PI / 2.0f));
	D3DXMatrixRotationY(&MatrixRotationY, (D3DX_PI / 2.0f));
	D3DXMatrixMultiply(&Matrix, &MatrixRotationY, &MatrixRotationX);
	D3DXVec3Transform(&TempVector, &Position, &Matrix);

	Position.x = TempVector.x;
	Position.y = TempVector.y;
	Position.z = TempVector.z;
}
