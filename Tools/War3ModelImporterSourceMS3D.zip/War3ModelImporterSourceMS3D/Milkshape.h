//+-----------------------------------------------------------------------------
//| Inclusion guard
//+-----------------------------------------------------------------------------
#ifndef MAGOS_MILKSHAPE_H
#define MAGOS_MILKSHAPE_H


//+-----------------------------------------------------------------------------
//| Included files
//+-----------------------------------------------------------------------------
#include "War3ModelBuilder.h"
#include <d3dx9.h>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>


//+-----------------------------------------------------------------------------
//| Milkshape header structure
//+-----------------------------------------------------------------------------
struct MILKSHAPE_HEADER
{
	CHAR MagicNumber[10];
	INT Version;
	INT SubVersion;
};


//+-----------------------------------------------------------------------------
//| Milkshape animation header structure
//+-----------------------------------------------------------------------------
struct MILKSHAPE_ANIMATION_HEADER
{
	FLOAT Fps;
	FLOAT CurrentTime;
	INT NrOfFrames;
};


//+-----------------------------------------------------------------------------
//| Milkshape vertex structure
//+-----------------------------------------------------------------------------
struct MILKSHAPE_VERTEX
{
	INT Flags;
	D3DXVECTOR3 Position;
	INT BoneIndex;
	INT ReferenceCount;
};


//+-----------------------------------------------------------------------------
//| Milkshape face structure
//+-----------------------------------------------------------------------------
struct MILKSHAPE_FACE
{
	INT Flags;
	INT Index1;
	INT Index2;
	INT Index3;
	D3DXVECTOR3 Normal1;
	D3DXVECTOR3 Normal2;
	D3DXVECTOR3 Normal3;
	D3DXVECTOR2 TexturePosition1;
	D3DXVECTOR2 TexturePosition2;
	D3DXVECTOR2 TexturePosition3;
	INT SmoothingGroup;
	INT GroupIndex;
};


//+-----------------------------------------------------------------------------
//| Milkshape group structure
//+-----------------------------------------------------------------------------
struct MILKSHAPE_GROUP
{
	INT Flags;
	std::string Name;
	INT NrOfFaces;
	std::vector<INT> FaceList;
	INT MaterialIndex;
};


//+-----------------------------------------------------------------------------
//| Milkshape material structure
//+-----------------------------------------------------------------------------
struct MILKSHAPE_MATERIAL
{
	std::string Name;
	D3DXCOLOR AmbientColor;
	D3DXCOLOR DiffuseColor;
	D3DXCOLOR SpecularColor;
	D3DXCOLOR EmissiveColor;
	FLOAT Shininess;
	FLOAT Transparency;
	INT Mode;
	std::string TextureFileName;
	std::string AlphaFileName;
};


//+-----------------------------------------------------------------------------
//| Milkshape rotation track structure
//+-----------------------------------------------------------------------------
struct MILKSHAPE_ROTATION_TRACK
{
	FLOAT Time;
	D3DXVECTOR3 Rotation;
};


//+-----------------------------------------------------------------------------
//| Milkshape translation track structure
//+-----------------------------------------------------------------------------
struct MILKSHAPE_TRANSLATION_TRACK
{
	FLOAT Time;
	D3DXVECTOR3 Translation;
};


//+-----------------------------------------------------------------------------
//| Milkshape joint structure
//+-----------------------------------------------------------------------------
struct MILKSHAPE_JOINT
{
	INT Flags;
	std::string Name;
	std::string ParentName;
	D3DXVECTOR3 Rotation;
	D3DXVECTOR3 Translation;
	INT NrOfRotationTracks;
	INT NrOfTranslationTracks;
	std::vector<MILKSHAPE_ROTATION_TRACK> RotationTrackList;
	std::vector<MILKSHAPE_TRANSLATION_TRACK> TranslationTrackList;
};


//+-----------------------------------------------------------------------------
//| File pointer structure
//+-----------------------------------------------------------------------------
struct FILE_POINTER
{
	union
	{
		CONST VOID* Void;

		CONST INT* Int;
		CONST CHAR* Char;
		CONST BYTE* Byte;
		CONST WORD* Word;
		CONST DWORD* DWord;
		CONST FLOAT* Float;
	};

	INT Size;
	CONST CHAR* First;
};


//+-----------------------------------------------------------------------------
//| Milkshape class
//+-----------------------------------------------------------------------------
class MILKSHAPE
{
	public:
		MILKSHAPE();
		~MILKSHAPE();

		VOID Clear();

		BOOL Import(WAR3_MODEL_BUILDER* ModelBuilder, CONST std::string& FileName, CONST CHAR* Data, INT DataSize);

	protected:
		BOOL ReadMilkshapeData(WAR3_MODEL_BUILDER* ModelBuilder);
		std::string ReadString(INT Size);

		BOOL BuildModel(WAR3_MODEL_BUILDER* ModelBuilder);

		VOID CorrectPosition(D3DXVECTOR3& Position);

		MILKSHAPE_HEADER Header;
		MILKSHAPE_ANIMATION_HEADER AnimationHeader;

		std::vector<MILKSHAPE_VERTEX> VertexList;
		std::vector<MILKSHAPE_FACE> FaceList;
		std::vector<MILKSHAPE_GROUP> GroupList;
		std::vector<MILKSHAPE_MATERIAL> MaterialList;
		std::vector<MILKSHAPE_JOINT> JointList;

		std::vector<std::string> GroupCommentList;
		std::vector<std::string> MaterialCommentList;
		std::vector<std::string> JointCommentList;
		std::vector<std::string> ModelCommentList;

		FILE_POINTER FilePointer;
		std::string CurrentFileName;

		BOOL CorrectCoordinateSystem;
};


//+-----------------------------------------------------------------------------
//| Global objects
//+-----------------------------------------------------------------------------
extern MILKSHAPE Milkshape;


//+-----------------------------------------------------------------------------
//| End of inclusion guard
//+-----------------------------------------------------------------------------
#endif
