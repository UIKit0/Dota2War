//+-----------------------------------------------------------------------------
//| Inclusion guard
//+-----------------------------------------------------------------------------
#ifndef MAGOS_MD2_H
#define MAGOS_MD2_H


//+-----------------------------------------------------------------------------
//| Included files
//+-----------------------------------------------------------------------------
#include "War3ModelBuilder.h"
#include <d3dx9.h>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <set>


//+-----------------------------------------------------------------------------
//| Md2 vertex structure
//+-----------------------------------------------------------------------------
struct MD2_VERTEX
{
	MD2_VERTEX()
	{
		Position = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		Normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		TexturePosition = D3DXVECTOR2(0.0f, 0.0f);
		Group = 0;
	}

	D3DXVECTOR3 Position;
	D3DXVECTOR3 Normal;
	D3DXVECTOR2 TexturePosition;
	INT Group;
};


//+-----------------------------------------------------------------------------
//| Md2 face structure
//+-----------------------------------------------------------------------------
struct MD2_FACE
{
	MD2_FACE()
	{
		Index1 = 0;
		Index2 = 0;
		Index3 = 0;
		TextureIndex1 = 0;
		TextureIndex2 = 0;
		TextureIndex3 = 0;
	}

	INT Index1;
	INT Index2;
	INT Index3;
	INT TextureIndex1;
	INT TextureIndex2;
	INT TextureIndex3;
};


//+-----------------------------------------------------------------------------
//| Md2 geoset structure
//+-----------------------------------------------------------------------------
struct MD2_GEOSET
{
	MD2_GEOSET()
	{
		//Empty
	}

	std::map<INT, INT> VertexMapping;
	std::vector<MD2_VERTEX> VertexList;
	std::vector<MD2_FACE> FaceList;
	std::vector<INT> GroupList;
};


//+-----------------------------------------------------------------------------
//| Md2 bone structure
//+-----------------------------------------------------------------------------
struct MD2_BONE
{
	MD2_BONE()
	{
		GeosetId = WAR3_INVALID_ID;
		GeosetAnimationId = WAR3_INVALID_ID;
	}

	INT GeosetId;
	INT GeosetAnimationId;
};


//+-----------------------------------------------------------------------------
//| Md2 sequence structure
//+-----------------------------------------------------------------------------
struct MD2_SEQUENCE
{
	MD2_SEQUENCE()
	{
		Name = "";
		StartFrame = 0;
		EndFrame = 0;
	}

	std::string Name;
	INT StartFrame;
	INT EndFrame;
};


//+-----------------------------------------------------------------------------
//| File pointer structure
//+-----------------------------------------------------------------------------
struct FILE_POINTER
{
	union
	{
		CONST VOID* Void;

		CONST INT* Int;
		CONST CHAR* Char;
		CONST BYTE* Byte;
		CONST WORD* Word;
		CONST DWORD* DWord;
		CONST FLOAT* Float;
	};

	INT Size;
	CONST CHAR* First;
};


//+-----------------------------------------------------------------------------
//| Md2 class
//+-----------------------------------------------------------------------------
class MD2
{
	public:
		MD2();
		~MD2();

		VOID Clear();

		BOOL Import(WAR3_MODEL_BUILDER* ModelBuilder, CONST std::string& FileName, CONST CHAR* Data, INT DataSize);

	protected:
		std::string GetSequenceName(CONST std::string& FrameName);

		FILE_POINTER FilePointer;
		std::string CurrentFileName;
};


//+-----------------------------------------------------------------------------
//| Global objects
//+-----------------------------------------------------------------------------
extern MD2 Md2;


//+-----------------------------------------------------------------------------
//| End of inclusion guard
//+-----------------------------------------------------------------------------
#endif
