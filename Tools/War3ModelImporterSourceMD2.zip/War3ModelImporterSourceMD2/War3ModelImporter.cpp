//+-----------------------------------------------------------------------------
//| Included files
//+-----------------------------------------------------------------------------
#include "War3ModelImporter.h"
#include "Md2.h"


//+-----------------------------------------------------------------------------
//| Imports a model
//+-----------------------------------------------------------------------------
extern "C" DLL BOOL DllImport(WAR3_MODEL_BUILDER* ModelBuilder, CONST CHAR* FileName, CONST CHAR* Data, INT DataSize)
{
	return Md2.Import(ModelBuilder, FileName, Data, DataSize);
}


//+-----------------------------------------------------------------------------
//| Main function that is run when the DLL is loaded and unloaded
//+-----------------------------------------------------------------------------
BOOL WINAPI DllMain(HINSTANCE Dll, DWORD Reason, LPVOID Reserved)
{
	return TRUE;
}
