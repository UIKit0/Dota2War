//+-----------------------------------------------------------------------------
//| Included files
//+-----------------------------------------------------------------------------
#include "Md2.h"


//+-----------------------------------------------------------------------------
//| Global objects
//+-----------------------------------------------------------------------------
MD2 Md2;


//+-----------------------------------------------------------------------------
//| Constructor
//+-----------------------------------------------------------------------------
MD2::MD2()
{
	FilePointer.Void = NULL;
	CurrentFileName = "";
}


//+-----------------------------------------------------------------------------
//| Destructor
//+-----------------------------------------------------------------------------
MD2::~MD2()
{
	Clear();
}


//+-----------------------------------------------------------------------------
//| Clears the current model data
//+-----------------------------------------------------------------------------
VOID MD2::Clear()
{
	FilePointer.Void = NULL;
	CurrentFileName = "";
}


//+-----------------------------------------------------------------------------
//| Imports an md2 model
//+-----------------------------------------------------------------------------
BOOL MD2::Import(WAR3_MODEL_BUILDER* ModelBuilder, CONST std::string& FileName, CONST CHAR* Data, INT DataSize)
{
	INT i;
	INT j;
	INT k;
	INT Size;
	INT Size2;
	INT Index;
	INT FrameIndex;
	INT TextureIndex;
	INT Version;
	INT TextureWidth;
	INT TextureHeight;
	INT FrameSize;
	INT NrOfTextures;
	INT NrOfVertices;
	INT NrOfTexturePositions;
	INT NrOfFaces;
	INT NrOfGlCommands;
	INT NrOfFrames;
	INT NrOfSequences;
	INT OffsetTextures;
	INT OffsetTexturePositions;
	INT OffsetFaces;
	INT OffsetFrames;
	INT OffsetGlCommands;
	INT OffsetEnd;
	INT LastAddedVertex;
	INT CurrentGeoset;
	INT CurrentFace;
	INT CurrentGroup;
	INT CurrentSequenceTime;
	INT SequenceTimeDifference;
	FLOAT TextureWidthFactor;
	FLOAT TextureHeightFactor;
	D3DXVECTOR3 Normal;
	D3DXVECTOR3 NormalVector1;
	D3DXVECTOR3 NormalVector2;
	D3DXVECTOR3 FrameScale;
	D3DXVECTOR3 FrameTranslation;
	D3DXVECTOR3 RelativePosition;
	WAR3_MODEL_MATERIAL Material;
	WAR3_MODEL_MATERIAL_LAYER MaterialLayer;
	std::vector<CHAR> FrameFileName;
	std::vector<CHAR> TextureFileName;
	std::vector<std::string> FrameNameList;
	std::vector<std::string> TextureList;
	std::vector<MD2_VERTEX> VertexList;
	std::vector<MD2_FACE> FaceList;
	std::vector<D3DXVECTOR2> TexturePositionList;
	std::vector<MD2_SEQUENCE> SequenceList;
	std::vector<MD2_GEOSET> GeosetList;
	std::vector<MD2_BONE> BoneList;
	std::string TempSequenceName;
	std::string CurrentSequenceName;
	std::set<INT> VertexSet;
	std::set<INT>::iterator VertexSetIterator;
	std::map<INT, INT>::iterator Iterator;
	FILE_POINTER FilePointer;

	Clear();

	FilePointer.Size = DataSize;
	FilePointer.First = Data;
	FilePointer.Char = FilePointer.First;
	CurrentFileName = FileName;

	FrameFileName.resize(17);
	TextureFileName.resize(65);

	if(*FilePointer.DWord++ != '2PDI')
	{
		ModelBuilder->SetErrorMessage("The file is not an MD2 model!");
		return FALSE;
	}

	Version = *FilePointer.DWord++;
	TextureWidth = *FilePointer.DWord++;
	TextureHeight = *FilePointer.DWord++;
	FrameSize = *FilePointer.DWord++;
	NrOfTextures = *FilePointer.DWord++;
	NrOfVertices = *FilePointer.DWord++;
	NrOfTexturePositions = *FilePointer.DWord++;
	NrOfFaces = *FilePointer.DWord++;
	NrOfGlCommands = *FilePointer.DWord++;
	NrOfFrames = *FilePointer.DWord++;
	OffsetTextures = *FilePointer.DWord++;
	OffsetTexturePositions = *FilePointer.DWord++;
	OffsetFaces = *FilePointer.DWord++;
	OffsetFrames = *FilePointer.DWord++;
	OffsetGlCommands = *FilePointer.DWord++;
	OffsetEnd = *FilePointer.DWord++;

	TextureWidthFactor = (TextureWidth == 0) ? 0.0f : (1.0f / static_cast<FLOAT>(TextureWidth));
	TextureHeightFactor = (TextureHeight == 0) ? 0.0f : (1.0f / static_cast<FLOAT>(TextureHeight));

	FrameNameList.resize(NrOfFrames);
	TextureList.resize(NrOfTextures);
	VertexList.resize(NrOfFrames * NrOfVertices);
	FaceList.resize(NrOfFaces);
	BoneList.resize(NrOfVertices);
	TexturePositionList.resize(NrOfTexturePositions);

	GeosetList.reserve(NrOfVertices);

	FilePointer.Char = &Data[OffsetTextures];

	for(i = 0; i < NrOfTextures; i++)
	{
		for(j = 0; j < 64; j++) TextureFileName[j] = *FilePointer.Char++;
		TextureFileName[64] = '\0';

		TextureList[i] = &TextureFileName[0];
	}

	FilePointer.Char = &Data[OffsetTexturePositions];

	for(i = 0; i < NrOfTexturePositions; i++)
	{
		TexturePositionList[i].x = (static_cast<FLOAT>(*FilePointer.Word++) * TextureWidthFactor);
		TexturePositionList[i].y = (static_cast<FLOAT>(*FilePointer.Word++) * TextureHeightFactor);
	}

	FilePointer.Char = &Data[OffsetFaces];

	for(i = 0; i < NrOfFaces; i++)
	{
		FaceList[i].Index3 = *FilePointer.Word++;
		FaceList[i].Index2 = *FilePointer.Word++;
		FaceList[i].Index1 = *FilePointer.Word++;
		FaceList[i].TextureIndex3 = *FilePointer.Word++;
		FaceList[i].TextureIndex2 = *FilePointer.Word++;
		FaceList[i].TextureIndex1 = *FilePointer.Word++;
	}

	FilePointer.Char = &Data[OffsetFrames];

	for(i = 0; i < NrOfFrames; i++)
	{
		FrameScale.x = *FilePointer.Float++;
		FrameScale.y = *FilePointer.Float++;
		FrameScale.z = *FilePointer.Float++;
		FrameTranslation.x = *FilePointer.Float++;
		FrameTranslation.y = *FilePointer.Float++;
		FrameTranslation.z = *FilePointer.Float++;

		for(j = 0; j < 16; j++) FrameFileName[j] = *FilePointer.Char++;
		FrameFileName[16] = '\0';

		FrameNameList[i] = &FrameFileName[0];

		TempSequenceName = GetSequenceName(FrameNameList[i]);
		if(TempSequenceName != CurrentSequenceName)
		{
			SequenceList.push_back(MD2_SEQUENCE());

			CurrentSequenceName = TempSequenceName;
			SequenceList.back().Name = CurrentSequenceName;
			SequenceList.back().StartFrame = i;
			SequenceList.back().EndFrame = i;
		}
		else
		{
			SequenceList.back().EndFrame = i;
		}

		for(j = 0; j < NrOfVertices; j++)
		{
			Index = (i * NrOfVertices) + j;

			VertexList[Index].Position.x = (FrameScale.x * static_cast<FLOAT>(*FilePointer.Byte++)) + FrameTranslation.x;
			VertexList[Index].Position.y = (FrameScale.y * static_cast<FLOAT>(*FilePointer.Byte++)) + FrameTranslation.y;
			VertexList[Index].Position.z = (FrameScale.z * static_cast<FLOAT>(*FilePointer.Byte++)) + FrameTranslation.z;

			D3DXVec3Normalize(&VertexList[Index].Normal, &VertexList[Index].Position);

			FilePointer.Byte++;
		}
	}

	for(i = 0; i < NrOfFaces; i++)
	{
		VertexList[FaceList[i].Index1].TexturePosition = TexturePositionList[FaceList[i].TextureIndex1];
		VertexList[FaceList[i].Index2].TexturePosition = TexturePositionList[FaceList[i].TextureIndex2];
		VertexList[FaceList[i].Index3].TexturePosition = TexturePositionList[FaceList[i].TextureIndex3];

		NormalVector1 = VertexList[FaceList[i].Index2].Position - VertexList[FaceList[i].Index1].Position;
		NormalVector2 = VertexList[FaceList[i].Index3].Position - VertexList[FaceList[i].Index1].Position;
		D3DXVec3Cross(&Normal, &NormalVector1, &NormalVector2);
		D3DXVec3Normalize(&Normal, &Normal);

		VertexList[FaceList[i].Index1].Normal = Normal;
		VertexList[FaceList[i].Index2].Normal = Normal;
		VertexList[FaceList[i].Index3].Normal = Normal;
	}

	CurrentFace = 0;
	CurrentGroup = 0;
	CurrentGeoset = 0;
	while(CurrentFace < NrOfFaces)
	{
		VertexSet.clear();
		GeosetList.push_back(MD2_GEOSET());

		while((CurrentFace < NrOfFaces) && (VertexSet.size() < 120))
		{
			VertexSet.insert(FaceList[CurrentFace].Index1);
			VertexSet.insert(FaceList[CurrentFace].Index2);
			VertexSet.insert(FaceList[CurrentFace].Index3);

			GeosetList[CurrentGeoset].FaceList.push_back(FaceList[CurrentFace]);
			CurrentFace++;
		}

		CurrentGroup = 0;
		VertexSetIterator = VertexSet.begin();
		while(VertexSetIterator != VertexSet.end())
		{
			Index = *VertexSetIterator;

			Size = static_cast<INT>(GeosetList[CurrentGeoset].FaceList.size());
			for(i = 0; i < Size; i++)
			{
				if(Index == GeosetList[CurrentGeoset].FaceList[i].Index1) GeosetList[CurrentGeoset].FaceList[i].Index1 = static_cast<INT>(GeosetList[CurrentGeoset].VertexList.size());
				if(Index == GeosetList[CurrentGeoset].FaceList[i].Index2) GeosetList[CurrentGeoset].FaceList[i].Index2 = static_cast<INT>(GeosetList[CurrentGeoset].VertexList.size());
				if(Index == GeosetList[CurrentGeoset].FaceList[i].Index3) GeosetList[CurrentGeoset].FaceList[i].Index3 = static_cast<INT>(GeosetList[CurrentGeoset].VertexList.size());
			}

			GeosetList[CurrentGeoset].VertexList.push_back(VertexList[Index]);
			GeosetList[CurrentGeoset].VertexList.back().Group = CurrentGroup;
			GeosetList[CurrentGeoset].GroupList.push_back(Index);

			VertexSetIterator++;
			CurrentGroup++;
		}

		CurrentGeoset++;
	}

	CurrentSequenceTime = 0;
	SequenceTimeDifference = 100;
	NrOfSequences = static_cast<INT>(SequenceList.size());

	for(i = 0; i < NrOfSequences; i++)
	{
		WAR3_MODEL_SEQUENCE Sequence;

		Sequence.Name = SequenceList[i].Name.c_str();
		Sequence.IntervalStart = (SequenceList[i].StartFrame * SequenceTimeDifference);
		Sequence.IntervalEnd = ((SequenceList[i].EndFrame + 1) * SequenceTimeDifference - 1);

		if(!ModelBuilder->CreateSequence(Sequence)) return FALSE;
	}

	for(i = 0; i < NrOfTextures; i++)
	{
		WAR3_MODEL_TEXTURE Texture;

		Texture.FileName = TextureList[i].c_str();
		if(!ModelBuilder->CreateTexture(Texture)) return FALSE;
	}

	if(!ModelBuilder->CreateMaterial(Material)) return FALSE;

	if(NrOfTextures > 0) MaterialLayer.TextureId = 0;
	if(!ModelBuilder->CreateMaterialLayer(0, MaterialLayer)) return FALSE;

	Size = static_cast<INT>(BoneList.size());
	for(i = 0; i < Size; i++)
	{
		std::string Name;
		std::stringstream Stream;
		WAR3_MODEL_BONE Bone;

		Stream << "Bone " << (i + 1);
		Name = Stream.str();

		Bone.Node.Name = Name.c_str();
		Bone.GeosetId = BoneList[i].GeosetId;
		Bone.GeosetAnimationId = BoneList[i].GeosetAnimationId;

		if(!ModelBuilder->CreateBone(Bone)) return FALSE;

		if(!ModelBuilder->CreateInterpolator()) return FALSE;
		ModelBuilder->SetInterpolatorType(WAR3_INTERPOLATOR_TYPE_VECTOR3);
		ModelBuilder->SetInterpolatorInterpolationType(WAR3_INTERPOLATION_TYPE_LINEAR);

		CurrentSequenceTime = 0;
		for(j = 0; j < NrOfFrames; j++)
		{
			WAR3_MODEL_VECTOR_3 Vector;

			Index = (j * NrOfVertices) + i;
			RelativePosition = VertexList[Index].Position - VertexList[i].Position;

			Vector.X = RelativePosition.x;
			Vector.Y = RelativePosition.y;
			Vector.Z = RelativePosition.z;

			ModelBuilder->AddVector3(CurrentSequenceTime, Vector, WAR3_MODEL_VECTOR_3(), WAR3_MODEL_VECTOR_3());

			for(k = 0; k < NrOfSequences; k++)
			{
				if(j == SequenceList[k].EndFrame)
				{
					FrameIndex = (SequenceList[k].StartFrame * NrOfVertices) + i;
					RelativePosition = VertexList[FrameIndex].Position - VertexList[i].Position;

					Vector.X = RelativePosition.x;
					Vector.Y = RelativePosition.y;
					Vector.Z = RelativePosition.z;

					ModelBuilder->AddVector3((CurrentSequenceTime + SequenceTimeDifference - 1), Vector, WAR3_MODEL_VECTOR_3(), WAR3_MODEL_VECTOR_3());
				}
			}

			CurrentSequenceTime += SequenceTimeDifference;
		}

		ModelBuilder->SetAnimatedBoneTranslation(i);
	}

	Size = static_cast<INT>(GeosetList.size());
	for(i = 0; i < Size; i++)
	{
		WAR3_MODEL_GEOSET Geoset;
		WAR3_MODEL_GEOSET_ANIMATION GeosetAnimation;

		Geoset.MaterialId = 0;
		if(!ModelBuilder->CreateGeoset(Geoset)) return FALSE;

		GeosetAnimation.GeosetId = i;
		if(!ModelBuilder->CreateGeosetAnimation(GeosetAnimation)) return FALSE;

		Size2 = static_cast<INT>(GeosetList[i].GroupList.size());
		for(j = 0; j < Size2; j++)
		{
			if(!ModelBuilder->CreateGeosetGroup(i)) return FALSE;
			if(!ModelBuilder->CreateGeosetGroupBone(i, j, GeosetList[i].GroupList[j])) return FALSE;
		}

		Size2 = static_cast<INT>(GeosetList[i].VertexList.size());
		for(j = 0; j < Size2; j++)
		{
			WAR3_MODEL_VERTEX Vertex;

			Vertex.Position.X = GeosetList[i].VertexList[j].Position.x;
			Vertex.Position.Y = GeosetList[i].VertexList[j].Position.y;
			Vertex.Position.Z = GeosetList[i].VertexList[j].Position.z;
			Vertex.Normal.X = GeosetList[i].VertexList[j].Normal.x;
			Vertex.Normal.Y = GeosetList[i].VertexList[j].Normal.y;
			Vertex.Normal.Z = GeosetList[i].VertexList[j].Normal.z;
			Vertex.TexturePosition.X = GeosetList[i].VertexList[j].TexturePosition.x;
			Vertex.TexturePosition.Y = GeosetList[i].VertexList[j].TexturePosition.y;
			Vertex.Group = GeosetList[i].VertexList[j].Group;

			if(!ModelBuilder->CreateGeosetVertex(i, Vertex)) return FALSE;
		}

		LastAddedVertex = Size2 - 1;

		Size2 = static_cast<INT>(GeosetList[i].FaceList.size());
		for(j = 0; j < Size2; j++)
		{
			WAR3_MODEL_FACE Face;

			Face.Index1 = GeosetList[i].FaceList[j].Index1;
			Face.Index2 = GeosetList[i].FaceList[j].Index2;
			Face.Index3 = GeosetList[i].FaceList[j].Index3;

			Index = GeosetList[i].FaceList[j].Index1;
			TextureIndex = GeosetList[i].FaceList[j].TextureIndex1;

			if(GeosetList[i].VertexList[Index].TexturePosition != TexturePositionList[TextureIndex])
			{
				WAR3_MODEL_VERTEX Vertex;

				Vertex.Position.X = GeosetList[i].VertexList[Index].Position.x;
				Vertex.Position.Y = GeosetList[i].VertexList[Index].Position.y;
				Vertex.Position.Z = GeosetList[i].VertexList[Index].Position.z;
				Vertex.Normal.X = GeosetList[i].VertexList[Index].Normal.x;
				Vertex.Normal.Y = GeosetList[i].VertexList[Index].Normal.y;
				Vertex.Normal.Z = GeosetList[i].VertexList[Index].Normal.z;
				Vertex.TexturePosition.X = TexturePositionList[TextureIndex].x;
				Vertex.TexturePosition.Y = TexturePositionList[TextureIndex].y;
				Vertex.Group = GeosetList[i].VertexList[Index].Group;

				if(!ModelBuilder->CreateGeosetVertex(i, Vertex)) return FALSE;
				LastAddedVertex++;

				Face.Index1 = LastAddedVertex;
			}

			Index = GeosetList[i].FaceList[j].Index2;
			TextureIndex = GeosetList[i].FaceList[j].TextureIndex2;

			if(GeosetList[i].VertexList[Index].TexturePosition != TexturePositionList[TextureIndex])
			{
				WAR3_MODEL_VERTEX Vertex;

				Vertex.Position.X = GeosetList[i].VertexList[Index].Position.x;
				Vertex.Position.Y = GeosetList[i].VertexList[Index].Position.y;
				Vertex.Position.Z = GeosetList[i].VertexList[Index].Position.z;
				Vertex.Normal.X = GeosetList[i].VertexList[Index].Normal.x;
				Vertex.Normal.Y = GeosetList[i].VertexList[Index].Normal.y;
				Vertex.Normal.Z = GeosetList[i].VertexList[Index].Normal.z;
				Vertex.TexturePosition.X = TexturePositionList[TextureIndex].x;
				Vertex.TexturePosition.Y = TexturePositionList[TextureIndex].y;
				Vertex.Group = GeosetList[i].VertexList[Index].Group;

				if(!ModelBuilder->CreateGeosetVertex(i, Vertex)) return FALSE;
				LastAddedVertex++;

				Face.Index2 = LastAddedVertex;
			}

			Index = GeosetList[i].FaceList[j].Index3;
			TextureIndex = GeosetList[i].FaceList[j].TextureIndex3;

			if(GeosetList[i].VertexList[Index].TexturePosition != TexturePositionList[TextureIndex])
			{
				WAR3_MODEL_VERTEX Vertex;

				Vertex.Position.X = GeosetList[i].VertexList[Index].Position.x;
				Vertex.Position.Y = GeosetList[i].VertexList[Index].Position.y;
				Vertex.Position.Z = GeosetList[i].VertexList[Index].Position.z;
				Vertex.Normal.X = GeosetList[i].VertexList[Index].Normal.x;
				Vertex.Normal.Y = GeosetList[i].VertexList[Index].Normal.y;
				Vertex.Normal.Z = GeosetList[i].VertexList[Index].Normal.z;
				Vertex.TexturePosition.X = TexturePositionList[TextureIndex].x;
				Vertex.TexturePosition.Y = TexturePositionList[TextureIndex].y;
				Vertex.Group = GeosetList[i].VertexList[Index].Group;

				if(!ModelBuilder->CreateGeosetVertex(i, Vertex)) return FALSE;
				LastAddedVertex++;

				Face.Index3 = LastAddedVertex;
			}

			if(!ModelBuilder->CreateGeosetFace(i, Face)) return FALSE;
		}
	}

	return TRUE;
}


//+-----------------------------------------------------------------------------
//| Extracts the sequence name from the frame name
//+-----------------------------------------------------------------------------
std::string MD2::GetSequenceName(CONST std::string& FrameName)
{
	INT i;
	INT Size;

	Size = static_cast<INT>(FrameName.size());

	for(i = 0; i < Size; i++)
	{
		if((FrameName[i] >= '0') && (FrameName[i] <= '9')) break;
	}

	return FrameName.substr(0, i);
}
